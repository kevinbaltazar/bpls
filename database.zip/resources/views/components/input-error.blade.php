@props (['for' => '', 'value' => ''])

<p class="mt-2 text-sm text-red-600" id="{{ $for }}-error">
    {{ $value }}
</p>
