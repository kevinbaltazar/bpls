<?php $attributes = $attributes->exceptProps([
    'type' => 'button',
    'class' => '',
    'variant' => 'primary',
    'variants' => [
        'primary' => 'text-white bg-indigo-600 hover:bg-indigo-700 focus:ring-indigo-500',
        'secondary' => 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-50 focus:ring-indigo-500',
        'success' => 'text-white bg-green-600 hover:bg-green-700 focus:ring-green-500',
        'info' => 'text-white bg-blue-600 hover:bg-blue-700 focus:ring-blue-500',
        'warning' => 'text-white bg-yellow-600 hover:bg-yellow-700 focus:ring-yellow-500',
        'error' => 'text-white bg-red-600 hover:bg-red-700 focus:ring-red-500',
        'select' => 'text-white bg-indigo-700 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500',
        'unselect' => 'mt-3 text-indigo-700 bg-indigo-100 hover:bg-indigo-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500',
    ]
]); ?>
<?php foreach (array_filter(([
    'type' => 'button',
    'class' => '',
    'variant' => 'primary',
    'variants' => [
        'primary' => 'text-white bg-indigo-600 hover:bg-indigo-700 focus:ring-indigo-500',
        'secondary' => 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-50 focus:ring-indigo-500',
        'success' => 'text-white bg-green-600 hover:bg-green-700 focus:ring-green-500',
        'info' => 'text-white bg-blue-600 hover:bg-blue-700 focus:ring-blue-500',
        'warning' => 'text-white bg-yellow-600 hover:bg-yellow-700 focus:ring-yellow-500',
        'error' => 'text-white bg-red-600 hover:bg-red-700 focus:ring-red-500',
        'select' => 'text-white bg-indigo-700 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500',
        'unselect' => 'mt-3 text-indigo-700 bg-indigo-100 hover:bg-indigo-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500',
    ]
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<button type="<?php echo e($type); ?>" <?php echo e($attributes->merge(['class' => 'inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 ' . $variants[$variant] . ' ' . $class])); ?>>
    <?php echo e($slot); ?>

</button>

<?php /**PATH C:\xampp\htdocs\barangay-clearance\resources\views/components/button.blade.php ENDPATH**/ ?>