<?php $attributes = $attributes->exceptProps([
    'class' => 'shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md',
    'type' => 'text',
    'name' => ''
]); ?>
<?php foreach (array_filter(([
    'class' => 'shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md',
    'type' => 'text',
    'name' => ''
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="mt-1">
    <input 
        type="<?php echo e($type); ?>" 
        name="<?php echo e($name); ?>" 
        id="<?php echo e($name); ?>" 
        <?php echo e($attributes->merge(['class' => 'shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md ' . $class])); ?>

    >
</div><?php /**PATH C:\xampp\htdocs\barangay-clearance\resources\views/components/input.blade.php ENDPATH**/ ?>