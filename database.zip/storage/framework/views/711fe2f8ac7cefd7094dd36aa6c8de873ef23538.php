<?php $attributes = $attributes->exceptProps([
    'variant' => 'success',
    'variants' => [
        'error' => 'bg-red-100 text-red-800',
        'warning' => 'bg-yellow-100 text-yellow-800',
        'success' => 'bg-green-100 text-green-800',
        'info' => 'bg-blue-100 text-blue-800',
    ]
]); ?>
<?php foreach (array_filter(([
    'variant' => 'success',
    'variants' => [
        'error' => 'bg-red-100 text-red-800',
        'warning' => 'bg-yellow-100 text-yellow-800',
        'success' => 'bg-green-100 text-green-800',
        'info' => 'bg-blue-100 text-blue-800',
    ]
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<span <?php echo e($attributes->merge(['class' => 'px-2 inline-flex text-xs leading-5 font-semibold rounded-full ' . $variants[$variant]])); ?>>
    <?php echo e($slot); ?>

</span><?php /**PATH C:\xampp\htdocs\barangay-clearance\resources\views/components/chip.blade.php ENDPATH**/ ?>