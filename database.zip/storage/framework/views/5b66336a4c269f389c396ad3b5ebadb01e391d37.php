<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

        <title>Apply</title>

        <style>
            input::-webkit-inner-spin-button,
            input::-webkit-outer-spin-button{
                -webkit-appearance: none;
                margin: 0;
            }
            input[type=number]{
                -moz-appearance: textfield;
            }
        </style>
    </head>
    <body>
       <?php echo $__env->yieldContent('application'); ?>
    </body>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script>
        function checkType(val)
        {
            var element = document.getElementById('type');
            if(val == 'others') 
            {
                element.style.display='block';
            }
            else  
            {
                element.style.display='none';
                
            }
            element.value = val;
            if(element.value == 'others')
            {
                element.value = '';
            }
        }
        
    </script>
</html>
<?php /**PATH C:\xampp\htdocs\barangay-clearance\resources\views/applicant/application.blade.php ENDPATH**/ ?>