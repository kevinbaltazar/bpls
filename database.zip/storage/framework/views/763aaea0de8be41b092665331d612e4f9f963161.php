<?php $attributes = $attributes->exceptProps([
    'for' => '', 
    'value' => '', 
    'class' => ''
]); ?>
<?php foreach (array_filter(([
    'for' => '', 
    'value' => '', 
    'class' => ''
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<label for="<?php echo e($for); ?>" <?php echo e($attributes->merge(['class' => 'block text-sm font-medium text-gray-700 ' . $class])); ?>>
    <?php echo e($value); ?>

</label><?php /**PATH C:\xampp\htdocs\barangay-clearance\resources\views/components/input-label.blade.php ENDPATH**/ ?>