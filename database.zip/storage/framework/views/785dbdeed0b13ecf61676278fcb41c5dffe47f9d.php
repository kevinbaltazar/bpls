<?php $attributes = $attributes->exceptProps([
    'class' => ' text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded',
    'type' => 'checkbox',
    'name' => ''
    
]); ?>
<?php foreach (array_filter(([
    'class' => ' text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded',
    'type' => 'checkbox',
    'name' => ''
    
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="">
    <input 
        type="<?php echo e($type); ?>" 
        name="<?php echo e($name); ?>" 
        id="<?php echo e($name); ?>" 
        <?php echo e($attributes->merge(['class' => 'h-4 w-4 mt-1 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded ' . $class])); ?>

    >
</div><?php /**PATH C:\xampp\htdocs\barangay-clearance\resources\views/components/input-checkbox.blade.php ENDPATH**/ ?>